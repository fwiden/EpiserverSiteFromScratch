//>>built
define("dojo/cldr/nls/pt-pt/currency",{"CAD_displayName":"Dólar canadiano","USD_displayName":"Dólar dos Estados Unidos"});