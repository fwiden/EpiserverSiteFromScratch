﻿define("epi-cms/content-approval/viewmodels/ApprovalStepViewModel", [
    "dojo/_base/declare",
    // Epi
    "epi-cms/content-approval/viewmodels/ReviewerViewModel",
    // Parent class
    "dojo/Stateful",
    "dojo/Evented",
    "epi/shell/DestroyableByKey",
    // Commands
    "epi-cms/content-approval/command/AddApprovalStep",
    "epi-cms/content-approval/command/RemoveApprovalStep",
    // Store modules
    "dojo/store/Memory",
    "dojo/store/Observable",
    //Resources
    "epi/i18n!epi/nls/episerver.cms.contentapproval"
], function (
    declare,
    // Epi
    ReviewerViewModel,
    // Parent class
    Stateful,
    Evented,
    DestroyableByKey,
    // Commands
    AddApprovalStep,
    RemoveApprovalStep,
    // Store modules
    Memory,
    Observable,
    //Resources
    localization
) {

    return declare([Stateful, DestroyableByKey, Evented], {
        // summary:
        //      The view model for an approval step.
        // tags:
        //      internal

        // reviewers: [public] Store
        //      Reviewers for the approval step.
        reviewers: null,

        // commands: [public] Array
        //      An array of commands available for the approval step.
        commands: null,

        // userStore: [readonly] Store
        //      A REST store for fetching data for users
        userStore: null,

        // canBeDeleted: [public] Boolean
        //      Indicates if the approval step can be deleted
        canBeDeleted: true,

        // isReadOnly: [readonly] Boolean
        //      Indicates if the approval step can be modified
        isReadOnly: false,

        // name: [public] String
        //      The name of the approval step that appears in the header.
        name: "",

        // isValid: [public] Boolean
        //      Indicates if the approval step can be saved
        isValid: true,

        // validationMessage: [readonly] String
        //      Holds the validation message when 'isValid' is false.
        validationMessage: null,

        // languages: [public] Array
        //      All the languages that is enable for the whole approval sequence
        languages: null,

        // showValidations: [public] Boolean
        //      Indicates if we are in a state where we want to show the validation messages.
        showValidations: false,

        addReviewer: function (reviewer) {
            // summary:
            //      Adds an reviewer.
            // reviewer: Object
            //      Reviewer to be added.
            // tags:
            //      public

            reviewer.languages = reviewer.languages || [];

            this.reviewers.add(this._createReviewer(reviewer));
        },

        filterOutExistingUsers: function (users) {
            // summary:
            //      Filters out existing users from the search result that
            //      is already in the reviewer list.
            // tags:
            //      public

            var reviewers = this.get("reviewers");

            //Remove already added users before displaying the
            //result so that we can't add them again
            return users = users.filter(function (user) {
                return !reviewers.get(user.userName);
            }, this);
        },

        filterReviewers: function (selectedLanguage) {
            // summary:
            //      Filters out reviewers that cannot approve the given language.
            // tags:
            //      public

            this.reviewers.query().forEach(function (reviewer) {
                // Reviewer can approve when "All languages" is selected,
                // or the reviewer is set for all languages.
                if (selectedLanguage === null || reviewer.languages.length === 0) {
                    reviewer.set("canApprove", true);
                    return;
                }

                // Or an reviewer can only approve languages it's set up for.
                var canApprove = reviewer.languages.some(function (language) {
                    return language === selectedLanguage;
                });
                reviewer.set("canApprove", canApprove);
            });
        },

        createApprovalStep: function () {
            // summary:
            //      Emits event for creating new approval step
            // tags:
            //      public
            this.emit("create-step", this);
        },

        removeApprovalStep: function () {
            // summary:
            //      Emits event for deleting approval step
            // tags:
            //      public
            this.emit("remove-step", this);
        },

        removeReviewer: function (reviewerId) {
            // summary:
            //      Removes reviewer by id
            // tags:
            //      public

            if (this.isReadOnly) {
                return;
            }

            this.reviewers.remove(reviewerId);
        },

        serialize: function () {
            // summary:
            //      Serialize approval step
            // tags:
            //      public

            var reviewers = this.reviewers.data.map(function (reviewer) {
                return reviewer.serialize();
            });

            return {
                name: this.name,
                reviewers: reviewers
            };
        },

        validate: function () {
            // summary:
            //      Checks if the approval step is valid and sets isValid and validationMessage.
            // tags:
            //      public

            if (!this.reviewers) {
                return;
            }

            var reviewers = this.reviewers.query(),
                validationMessage = this._validateReviewers(reviewers);

            if (!validationMessage) {
                validationMessage = this._validateLanguages(reviewers);
            }

            // validationMessage should be set before setting isValid as there might be watchers on isValid.
            this.set("validationMessage", validationMessage);
            this.set("isValid", !validationMessage);
        },

        _createReviewer: function (reviewer) {
            // summary:
            //      Creates ReviewerViewModel and hooking up language event that emits change event. Triggers validation.
            // tags:
            //      private
            var viewModel = new ReviewerViewModel(reviewer);

            this.own(
                viewModel.watch("languages", function () {
                    this.validate();
                    this.emit("change");
                }.bind(this))
            );

            this.validate();
            return viewModel;
        },

        _nameSetter: function (value) {
            // summary:
            //      Sets the name property and emit change event
            // tags:
            //      protected

            // If the value is null or undefined then set an empty string instead.
            value = value || "";

            if (value === this.name) {
                return;
            }
            this.name = value;
            this.emit("change");
        },

        _nameGetter: function () {
            // summary:
            //      Gets the name property if any exist; otherwise returns the placeholder.
            // tags:
            //      protected

            return this.name || localization.step.header.placeholder;
        },

        _reviewersSetter: function (reviewers) {
            // summary:
            //      Transforms a list of reviewers into ReviewerViewModels and creates an observable memory store
            //      and observe the store for changes. Triggers validation.
            // tags:
            //      protected

            var viewModels = reviewers.map(function (reviewer) {
                return this._createReviewer(reviewer);
            }, this);

            this.reviewers = Observable(new Memory({
                idProperty: "userName",
                data: viewModels
            }));

            this.destroyByKey("reviewersObserveHandle");
            this.ownByKey("reviewersObserveHandle", this.reviewers.query().observe(function () {
                // Validate when reviewers change.
                this.validate();
                this.emit("change");
            }.bind(this)));

            // Validate when setting new reviewers.
            this.validate();
        },

        _commandsGetter: function () {
            // summary:
            //      Lazy loads the commands associated with the approval step.
            // tags:
            //      protected

            if (this.commands === null) {
                this.commands = [
                    new AddApprovalStep({ model: this }),
                    new RemoveApprovalStep({ model: this })
                ];
            }
            return this.commands;
        },

        _validateLanguages: function (reviewers) {
            // summary:
            //      Validates if the approvalStep have reviewers in all languages and
            //      returns the validationMessage
            // tags:
            //      private

            var validationMessage = null;

            if (!this.languages) {
                return validationMessage;
            }

            this.languages.forEach(function (definitionLanguage) {
                var hasLanguageReviewers = reviewers.some(function (reviewer) {
                    //When the reviewer is set to approve all languages
                    if (reviewer.languages.length === 0) {
                        return true;
                    }

                    //Otherwise verify that it approves this current language.
                    return reviewer.languages.some(function (reviewerLanguage) {
                        return reviewerLanguage === definitionLanguage.value;
                    });
                });

                if (!hasLanguageReviewers) {
                    // validation message can contain multiple missing languages with the same localized error message
                    if (validationMessage) {
                        validationMessage.languages.push(definitionLanguage.value);
                    } else {
                        validationMessage = {
                            value: localization.validationmessage.notenoughlanguagesmessage.title,
                            languages: [definitionLanguage.value],
                            level: "warning"
                        };
                    }
                }
            });

            return validationMessage;
        },

        _validateReviewers: function (reviewers) {
            // summary:
            //      Validates if the approvalStep have any reviewers
            // tags:
            //      private

            var validationMessage = null;

            var hasReviewers = reviewers.length > 0;
            if (!hasReviewers) {
                validationMessage = {
                    value: localization.validationmessage.notenoughreviewersmessage.title,
                    languages: null,
                    level: "error"
                };
            }

            return validationMessage;
        }
    });
});
